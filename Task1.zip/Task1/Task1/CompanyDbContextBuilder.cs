﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System;
using System.Collections.Generic;
using System.Text;

namespace Task1
{
    public class CompanyDbContextBuilder : IDesignTimeDbContextFactory<CompanyDbContext>
    {
        public CompanyDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<CompanyDbContext>();
            optionsBuilder.UseSqlServer("server=.;user id=sa;password=M8$tek12;database=SampleDb1;TrustServerCertificate=true;");
            return new CompanyDbContext(optionsBuilder.Options);
        }
    }
}
