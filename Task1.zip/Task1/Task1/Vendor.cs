﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Task1
{
    public class Vendor
    {
        [Key]
        public int VendorId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string ContactPerson { get; set; }
        public long Phone { get; set; }
    }
}
