﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task1;

namespace Task1
{
   public class VendorRepository : IVendorRepository
    {
        CompanyDbContext context = null;
        public VendorRepository(CompanyDbContext context)
        {
            this.context = context;
        }

        public void AddVendor(Vendor vendor)
        {
            context.Vendors.Add(vendor);
            context.SaveChanges();

        }

        public IEnumerable<Vendor> GetAllVendor()
        {
            return context.Vendors.ToList();
        }

        public Vendor GetVendorById(int Id)
        {
            return context.Vendors.Where(ven => ven.VendorId.Equals(Id)).FirstOrDefault();

        }

        public Vendor GetVendorByName(string name)
        {
            return context.Vendors.Where(ven => ven.Name.Equals(name)).FirstOrDefault();

        }

        public void RemoveVendor(int id)
        {
            var emp = context.Vendors.Find(id);
            context.Vendors.Remove(emp);
            context.SaveChanges();
        }

        public void UpdateVendor(Vendor vendor)
        {
            Vendor emp = context.Vendors.Where(emp => emp.VendorId == vendor.VendorId).First();
            emp.Name = vendor.Name;
            emp.Address = vendor.Address;
            emp.ContactPerson = vendor.ContactPerson;
            emp.Phone = vendor.Phone;
            context.SaveChanges();
        }
    }
}
