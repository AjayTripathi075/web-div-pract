﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
   public interface IVendorRepository
    {
        void AddVendor(Vendor vendor);
        IEnumerable<Vendor> GetAllVendor();
        Vendor GetVendorByName(string name);
        Vendor GetVendorById(int  Id);

        void RemoveVendor(int id);
        void UpdateVendor(Vendor vendor);

    }
}
