﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task1;

namespace Task1
{
    public class ContractRepository : IContractRepository
    {
        CompanyDbContext context = null;
        public ContractRepository(CompanyDbContext context)
        {
            this.context = context;
        }

        public void AddContract(Contract contract)
        {
            context.Contracts.Add(contract);
            context.SaveChanges();
        }

        public IEnumerable<Contract> GetAllContract()
        {
            return context.Contracts.ToList();
        }

        public Contract GetContractById(int Id)
        {
            return context.Contracts.Where(con => con.ContactId.Equals(Id)).FirstOrDefault();

        }

        public void RemoveContract(int id)
        {
            var con = context.Contracts.Find(id);
            context.Contracts.Remove(con);
            context.SaveChanges();

        }

        public void UpdateContract(Contract contract)
        {
            context.Entry<Contract>(contract).State = EntityState.Modified;
            context.SaveChanges();

        }
    }
}
