﻿using System;
using System.Collections.Generic;
using System.Text;
using Task1;

namespace Task1
{
    public class RepositoryBuilder
    {
        public readonly IContractRepository ContractRepository = null;
        public readonly IVendorRepository VendorRepository = null;

        public RepositoryBuilder()
        {
            CompanyDbContextBuilder contextBuilder = new CompanyDbContextBuilder();
            var context = contextBuilder.CreateDbContext(new string[] { string.Empty });

            this.ContractRepository = new ContractRepository(context);
            this.VendorRepository = new VendorRepository(context);
        }
    }
}
