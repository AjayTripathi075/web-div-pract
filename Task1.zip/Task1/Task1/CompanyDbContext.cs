﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace Task1
{
    public class CompanyDbContext : DbContext
    {
        public CompanyDbContext()
        {

        }

        public CompanyDbContext(DbContextOptions<CompanyDbContext> options) : base(options)
        {
            
        }
        public DbSet<Vendor> Vendors { get; set; }

        public DbSet<Contract> Contracts { get; set; }
    }
}
