﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
   public interface IContractRepository
    {
        void AddContract(Contract contract);
        IEnumerable<Contract> GetAllContract();
        Contract GetContractById(int Id);
        void RemoveContract(int id);
        void UpdateContract(Contract contract);

    }
}
